package Shopping;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ShoppingDao {
	ConnectionPr c=new ConnectionPr();
	Connection con=c.getConnection();
	PreparedStatement pstate;
	public void Billingdb(List<Product> b){
		for(Product bill:b){
			try {
				System.out.println("The connection was at :"+con);
				pstate=con.prepareStatement
						("Insert into plist values(?,?,?,?)");
				pstate.setInt(1,bill.getpId());
				pstate.setString(2, bill.getpName());
				pstate.setFloat(3,bill.getpPrice());
				pstate.setInt(4, bill.getpQty());
				int i=pstate.executeUpdate();
				if(i>0){
					System.out.println("Executed successfully");
				}
				else{
					System.out.println("Not Executed");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		}
			}
	public List<Product> ReturnBill(){
		List<Product> prod=new ArrayList<Product>();
		try {
			pstate = con.prepareStatement("Select * from plist");
			ResultSet res=pstate.executeQuery();
			ResultSetMetaData rsmd=res.getMetaData();
			int ColumnNumbers=rsmd.getColumnCount();
			while(res.next()){
					int  pId=res.getInt(1);
					String pName=res.getString(2);
					float pPrice=res.getFloat(3);
					int pQty=res.getInt(4);
					Product pr=new Product(pId, pName, pPrice, pQty);
					prod.add(pr);
				}
					} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prod;
	}
	
	public void clearBill(){
		try {
			pstate=con.prepareStatement("Delete from plist");
			int i=pstate.executeUpdate();
			if(i>0){
				System.out.println("All rows are deleted");
			}
			else {
				System.out.println("All rows not deleted");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
/*
create table plist(
pId INT,
pName varchar2(40),
pPrice FLOAT,
pQty INT
 ); 
 */
